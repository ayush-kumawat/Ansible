#!/bin/bash

cp /root/test.js  /root/delete.txt
