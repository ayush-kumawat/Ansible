#!/usr/bin/node
console.log("Hello")

